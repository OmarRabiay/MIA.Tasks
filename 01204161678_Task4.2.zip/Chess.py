import pygame
import sys

pygame.init()

WIDTH, HEIGHT = 800, 800
ROWS, COLS = 8, 8
SQUARE_SIZE = WIDTH // COLS

WHITE = (255, 255, 255)
BLACK = (112,173,89)
GREEN = (0, 255, 0)  
RED = (255, 0, 0)  

def load_images():
    pieces = ['bB', 'bK', 'bN', 'bP', 'bQ', 'bR', 'wB', 'wK', 'wN', 'wP', 'wQ', 'wR']
    images = {}
    for piece in pieces:
        images[piece] = pygame.transform.scale(pygame.image.load(f'images/{piece}.png'), (SQUARE_SIZE, SQUARE_SIZE))
    return images

def draw_board(screen, flip=False):
    colors = [WHITE, BLACK]
    for row in range(ROWS):
        for col in range(COLS):
            color = colors[(row + col) % 2]
            if not flip:
                pygame.draw.rect(screen, color, (col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))
            else:
                pygame.draw.rect(screen, color, ((COLS - col - 1) * SQUARE_SIZE, (ROWS - row - 1) * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))

def draw_pieces(screen, board, images, flip=False):
    for row in range(ROWS):
        for col in range(COLS):
            piece = board[row][col]
            if piece != '--':
                if not flip:
                    screen.blit(images[piece], (col * SQUARE_SIZE, row * SQUARE_SIZE))
                else:
                    screen.blit(images[piece], ((COLS - col - 1) * SQUARE_SIZE, (ROWS - row - 1) * SQUARE_SIZE))

def move_piece(board, start_pos, end_pos):
    piece = board[start_pos[0]][start_pos[1]]
    board[start_pos[0]][start_pos[1]] = '--'
    board[end_pos[0]][end_pos[1]] = piece

def is_valid_move(board, start_pos, end_pos):
    start_row, start_col = start_pos
    end_row, end_col = end_pos
    start_piece = board[start_row][start_col]
    end_piece = board[end_row][end_col]

    if start_piece == '--':
        return False
 
    if start_piece[0] == board[end_row][end_col][0]:
        return False

    if start_piece[1] == 'P':  
        if start_piece[0] == 'w':
            if start_row == 6:  
                if end_row == start_row - 2 and start_col == end_col and board[start_row - 1][start_col] == '--' and end_piece == '--':
                    return True
            if end_row == start_row - 1 and start_col == end_col and end_piece == '--':
                return True
            elif end_row == start_row - 1 and abs(end_col - start_col) == 1 and end_piece != '--' and end_piece[0] == 'b':
                return True
        elif start_piece[0] == 'b':
            if start_row == 1:  
                if end_row == start_row + 2 and start_col == end_col and board[start_row + 1][start_col] == '--' and end_piece == '--':
                    return True
            if end_row == start_row + 1 and start_col == end_col and end_piece == '--':
                return True
            elif end_row == start_row + 1 and abs(end_col - start_col) == 1 and end_piece != '--' and end_piece[0] == 'w':
                return True
        return False
    elif start_piece[1] == 'R':  
        if start_row == end_row:  
            step = 1 if end_col > start_col else -1
            for col in range(start_col + step, end_col, step):
                if board[start_row][col] != '--':
                    return False
            return True
        elif start_col == end_col:  
            step = 1 if end_row > start_row else -1
            for row in range(start_row + step, end_row, step):
                if board[row][start_col] != '--':
                    return False
            return True
    elif start_piece[1] == 'N':  
        if (abs(start_row - end_row) == 2 and abs(start_col - end_col) == 1) or (abs(start_row - end_row) == 1 and abs(start_col - end_col) == 2):
            return True
    elif start_piece[1] == 'B':  
        if abs(start_row - end_row) == abs(start_col - end_col):
            step_row = 1 if end_row > start_row else -1
            step_col = 1 if end_col > start_col else -1
            row, col = start_row + step_row, start_col + step_col
            while row != end_row and col != end_col:
                if board[row][col] != '--':
                    return False
                row += step_row
                col += step_col
            return True
    elif start_piece[1] == 'Q':  
        if start_row == end_row or start_col == end_col or abs(start_row - end_row) == abs(start_col - end_col):
            if start_row == end_row:  
                step = 1 if end_col > start_col else -1
                for col in range(start_col + step, end_col, step):
                    if board[start_row][col] != '--':
                        return False
                return True
            elif start_col == end_col:  
                step = 1 if end_row > start_row else -1
                for row in range(start_row + step, end_row, step):
                    if board[row][start_col] != '--':
                        return False
                return True
            elif abs(start_row - end_row) == abs(start_col - end_col):  
                step_row = 1 if end_row > start_row else -1
                step_col = 1 if end_col > start_col else -1
                row, col = start_row + step_row, start_col + step_col
                while row != end_row and col != end_col:
                    if board[row][col] != '--':
                        return False
                    row += step_row
                    col += step_col
                return True
    elif start_piece[1] == 'K':  
        if abs(start_row - end_row) <= 1 and abs(start_col - end_col) <= 1:
            return True

    return False

def get_valid_moves(board, start_pos):
    valid_moves = []
    start_row, start_col = start_pos
    start_piece = board[start_row][start_col]
 
    for row in range(ROWS):
        for col in range(COLS):
            end_pos = (row, col)
            if is_valid_move(board, start_pos, end_pos):
                valid_moves.append(end_pos)

    return valid_moves

def is_in_check(board, color):
    
    king_pos = None
    for row in range(ROWS):
        for col in range(COLS):
            if board[row][col] == f'{color}K':
                king_pos = (row, col)
                break
        if king_pos:
            break
    
    if not king_pos:
        return False
  
    opponent_color = 'b' if color == 'w' else 'w'
    for row in range(ROWS):
        for col in range(COLS):
            if board[row][col][0] == opponent_color:
                if is_valid_move(board, (row, col), king_pos):
                    return True

    return False

def is_checkmate(board, turn):
    if not is_in_check(board, turn):
        return False
    
    for r in range(len(board)):
        for c in range(len(board[r])):
            if board[r][c].startswith(turn):
                valid_moves = get_valid_moves(board, (r, c))
                for move in valid_moves:
                    temp_board = [row[:] for row in board]
                    move_piece(temp_board, (r, c), move)
                    if not is_in_check(temp_board, turn):
                        return False
    return True

def main():
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Chess')
    images = load_images()

    board = [
        ['bR', 'bN', 'bB', 'bQ', 'bK', 'bB', 'bN', 'bR'],
        ['bP', 'bP', 'bP', 'bP', 'bP', 'bP', 'bP', 'bP'],
        ['--', '--', '--', '--', '--', '--', '--', '--'],
        ['--', '--', '--', '--', '--', '--', '--', '--'],
        ['--', '--', '--', '--', '--', '--', '--', '--'],
        ['--', '--', '--', '--', '--', '--', '--', '--'],
        ['wP', 'wP', 'wP', 'wP', 'wP', 'wP', 'wP', 'wP'],
        ['wR', 'wN', 'wB', 'wQ', 'wK', 'wB', 'wN', 'wR']
    ]

    selected_piece = None
    turn = 'w'  
    flip_board = False  
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if flip_board:
                    row = (HEIGHT - pos[1]) // SQUARE_SIZE
                    col = (WIDTH - pos[0]) // SQUARE_SIZE
                else:
                    row = pos[1] // SQUARE_SIZE
                    col = pos[0] // SQUARE_SIZE
                
                piece = board[row][col]
                if selected_piece is None:
                    if piece != '--' and piece[0] == turn:  
                        selected_piece = (row, col)
                else:
                    if (row, col) in get_valid_moves(board, selected_piece):
                        
                        temp_board = [r[:] for r in board]
                        move_piece(temp_board, selected_piece, (row, col))
                        
                        
                        if is_in_check(temp_board, turn):
                            print("Illegal move, King is in check.")
                        else:
                            
                            move_piece(board, selected_piece, (row, col))
                            turn = 'b' if turn == 'w' else 'w'  
                            flip_board = not flip_board  

                            
                            if is_checkmate(board, 'b' if turn == 'w' else 'w'):
                                print(f"Checkmate! {turn} wins.")
                                running = False

                        selected_piece = None

        screen.fill((0, 0, 0))  
        if flip_board:
            draw_board(screen, flip=True)
            draw_pieces(screen, board, images, flip=True)
        else:
            draw_board(screen, flip=False)
            draw_pieces(screen, board, images, flip=False)
        
        if selected_piece:
            valid_moves = get_valid_moves(board, selected_piece)
            for move in valid_moves:
                if flip_board:
                    pygame.draw.circle(screen, GREEN, ((COLS - move[1] - 1) * SQUARE_SIZE + SQUARE_SIZE // 2, (ROWS - move[0] - 1) * SQUARE_SIZE + SQUARE_SIZE // 2), SQUARE_SIZE // 6)
                else:
                    pygame.draw.circle(screen, GREEN, (move[1] * SQUARE_SIZE + SQUARE_SIZE // 2, move[0] * SQUARE_SIZE + SQUARE_SIZE // 2), SQUARE_SIZE // 6)
        if is_checkmate(board, turn):
            font = pygame.font.Font(None, 36)
            if turn == 'b':
                text = font.render("Checkmate! White won!" , True, (0,0,150))
            else :
                text = font.render("Checkmate! Black won!" , True, (0,0,150))
            
            text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
            screen.blit(text, text_rect)
        
        
        elif is_in_check(board, turn):
            font = pygame.font.Font(None, 36)
            text = font.render("Check!", True, RED)
            text_rect = text.get_rect(center=(WIDTH // 2, HEIGHT // 2))
            screen.blit(text, text_rect)
        
        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()